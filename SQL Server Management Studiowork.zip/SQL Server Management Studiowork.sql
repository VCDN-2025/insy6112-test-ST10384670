-- Q.3.1: Create the Customer table
CREATE TABLE Customer (
    CustomerID INT PRIMARY KEY,
    CustomerFullName VARCHAR(100),
    CustomerEmail VARCHAR(100)
);

-- Q.3.2: Create the Orders table
CREATE TABLE Orders (
    OrderID INT PRIMARY KEY,
    OrderNumber VARCHAR(20),
    CustomerID INT,
    OrderDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID)
);

-- Q.3.3: Insert data into Customer table
INSERT INTO Customer (CustomerID, CustomerFullName, CustomerEmail)
VALUES (1, 'Debbie Duncan', 'dduncan@yahoo.com');

-- Q.3.3: Insert data into Orders table
INSERT INTO Orders (OrderID, OrderNumber, CustomerID, OrderDate)
VALUES (1, '020149', 1, '2025-02-14');
